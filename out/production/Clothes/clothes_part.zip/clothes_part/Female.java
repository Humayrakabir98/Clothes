package clothes_part;

public class Female extends Clothes {
    public Female(String name, double price) {
        super(name,price);
    }
}
