package clothes_part;

public class Male extends Clothes{
    public Male(String name, double price){
        super(name, price);
    }
}
