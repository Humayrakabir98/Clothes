package clothes_part;

public class Jewellery extends Clothes{
    public Jewellery(String name, double price){
        super(name, price);
    }
}
