package clothes_part;

public class ClothesMainRun {
    public static void main(String[] args) {
        ClothesMainMethod obj = new ClothesMainMethod();
        obj.clotheAllMethod();
    }
}
